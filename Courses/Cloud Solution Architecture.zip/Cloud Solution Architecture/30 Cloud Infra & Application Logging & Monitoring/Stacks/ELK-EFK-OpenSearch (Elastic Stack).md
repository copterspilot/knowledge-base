[Search and Analytics: Elasticsearch, Logstash, and Kibana](https://deepwiki.com/docker-library/docs/3.3-search-and-analytics:-elasticsearch-logstash-and-kibana)

![](../../~assets~/pics/ELS_Stack_Scheme.png)